print('first 모듈 시작')
print('first.py __name__:', __name__)    # __name__ 변수 출력
print('first 모듈 끝')