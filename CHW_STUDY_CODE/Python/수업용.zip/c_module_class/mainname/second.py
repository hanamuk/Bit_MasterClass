import first  # fist 모듈을 가져옴 -> 에러나지만 관계없음

print('second.py __name__:', __name__)  # __name__ 변수 출력